import java.util.Scanner;

public class Calc {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        while (true) {

            System.out.println("Ввыдите числа от 1 до 10 (арабские или римские) и тип операции (+, -, /, *): ");
            String line = scanner.nextLine();

            try {
                String[] symbols = line.split(" ");
                if (symbols.length != 3) throw new Exception("Ошибка");

                BackChoice firstNumber = ChoiceSymbols.Validation(symbols[0]);
                BackChoice secondNumber = ChoiceSymbols.Validation(symbols[2], firstNumber.getType());
                String result = CalcFunction.calculator(firstNumber, secondNumber, symbols[1]);
                System.out.println("Итого: \n" + result);

            } catch (Exception e) {
                System.out.println(e.getMessage());
                break;
            }
        }

        scanner.close();
    }

}
