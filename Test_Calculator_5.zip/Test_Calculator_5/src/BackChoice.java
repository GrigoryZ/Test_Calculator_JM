public class BackChoice {

    private int value;
    private static ChoiceLanguage type;

    BackChoice(int value, ChoiceLanguage type) {
        this.value = value;
        this.type = type;
    }

    int getValue() {
        return value;
    }

    static ChoiceLanguage getType() {
        return type;
    }

}
