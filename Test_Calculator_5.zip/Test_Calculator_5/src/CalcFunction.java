public class CalcFunction {

    public static String calculator(BackChoice first, BackChoice second, String action) throws Exception {

        int result;

        switch (action) {
            case "+":
                result = first.getValue() + second.getValue();
                break;
            case "-":
                result = first.getValue() - second.getValue();
                break;
            case "*":
                result = first.getValue() * second.getValue();
                break;
            case "/":
                result = first.getValue() / second.getValue();
                break;
            default:
                throw new Exception("Ошибка");
        }

        if (first.getType() == ChoiceLanguage.rome) {
            return ChoiceSymbols.ChangeToRome(result);
        } else return String.valueOf(result);
    }

}
