import java.util.Map;
import java.util.TreeMap;

public class ChoiceSymbols {

    private final static TreeMap< Integer, String > romanString = new TreeMap<>();

    static {
        romanString.put(1, "I");
        romanString.put(4, "IV");
        romanString.put(5, "V");
        romanString.put(9, "IX");
        romanString.put(10, "X");
        romanString.put(40, "XL");
        romanString.put(50, "L");
        romanString.put(90, "XC");
        romanString.put(100, "C");
    }

    static BackChoice Validation(String symbol) throws Exception {

        int value;
        ChoiceLanguage type;

        try {
            value = Integer.parseInt(symbol);
            type = ChoiceLanguage.norm;
        }catch (NumberFormatException e) {
            value = toArabicNumber(symbol);
            type = ChoiceLanguage.rome;
        }

        if (value < 1 || value > 10) {
            throw new Exception("Ошибка");
        }

        return new BackChoice(value, type);
    }

    static BackChoice Validation(String symbol, ChoiceLanguage type) throws Exception {

        BackChoice backChoice = Validation(symbol);
        if (BackChoice.getType() != type) {
            throw new Exception("Можно производить операции только с одним типом чисел");
        }

        return backChoice;
    }

    private static int StringToNumber(char letter) {

        int result = -1;

        for (Map.Entry < Integer, String > entry: romanString.entrySet()) {
            if (entry.getValue().equals(String.valueOf(letter))) result = entry.getKey();
        }
        return result;
    }

    static String ChangeToRome(int number) {

        int i = romanString.floorKey(number);

        if (number == i) {
            return romanString.get(number);
        }
        return romanString.get(i) + ChangeToRome(number - i);
    }

    static int toArabicNumber(String roman) throws Exception {
        int result = 0;

        int i = 0;
        while (i < roman.length()) {
            char letter = roman.charAt(i);
            int num = StringToNumber(letter);

            if (num < 0) throw new Exception("Будьте внимательнее");

            i++;
            if (i == roman.length()) {
                result += num;
            }else {
                int nextNum = StringToNumber(roman.charAt(i));
                if(nextNum > num) {
                    result += (nextNum - num);
                    i++;
                }
                else result += num;
            }
        }
        return result;
    }

}
